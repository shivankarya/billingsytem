package com.shivank.billingsystem.item;

/**
 * Enum to represent various item types.
 */
public enum ItemType {

	GROCERY, 
	BOOKS, 
	APPARELS, 
	OTHERS;
}
